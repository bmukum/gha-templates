# SportsEngine GitHub Actions Workflow Templates
Centralized repository for reusable GitHub Actions workflow templates.

Currently, per [GitHub documentation](https://docs.github.com/en/actions/learn-github-actions/reusing-workflows#creating-a-reusable-workflow), reusable workflows must be placed directly in the `.github/workflows` directory and do not support sub-directories. Due to this all workflows should be prefixed with an identifier related to their use (eg `terraform-`).

## TODO
### Terraform
- Additional linting (TFLINT or similar)
- Add documentation jobs
- Add linting/testing to the workflow repository itself (https://github.community/t/need-linter-for-github-actions-workflows-configuration/16384/12)

## Terraform
Workflows for running Terraform through GitHub Actions, including linting, planning, and applies.

### Jobs
**Terraform Lint** - Runs a `terraform fmt -recursive -check`. It also performs checkov scans on the terraform files for the presence of misconfigurations that may lead to security problems. Optionally initializes the module and runs a `terraform validate`.
**Terraform Plan** - Initializes the module and creates a Terraform plan, then posts the plan contents to the PR.  If an [Infracost API key](https://www.infracost.io/docs/#2-get-api-key) is provided as a secret, it will generate an Infracost breakdown.
**Terraform Apply** - Initializes the module, downloads the plan file from the `Terraform Plan` workflow, and applies the plan.  Requires the `dawidd6/action-download-artifact@v2` action to be allowed.
**Terraform Plan-Apply** - Combined workflow to handle Terraform plans and applies to work around the limitations of the `actions/download-artifact@v2` action's capabilities with artifacts.

### Remote Modules
Since the `GITHUB_TOKEN` environment variable automatically provided to GitHub Actions runs is scoped only to the local repository, the workflows are unable to download modules from other repositories within the organization.  To work around this limitation, a secret has been added to the workflows that expects a [Personal Access Token](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token) with permissions to clone private or internal repositories within the organization owning each module.  This is then used in a workflow step that inserts it into each module's source to enable authentication to GitHub.  This requires all remote modules to use an HTTPS source with the format `git::https://github.com/<ORGANIZATION>/<REPOSITORY>.git//<MODULE_NAME>?ref=<REF>`.

The PAT will then need to be added as a repository secret in the root-level module's repository and passed in through the workflow call.

### Inputs
| Name | Description | Type | Default | Required | Jobs |
|------|-------------|------|---------|---------|-------|
| init | Boolean whether or not to initalize the directory.  Most likely will not be needed with module directories.  Required for `terraform validate`. | `boolean` | `false` | no | `Lint` |
| check_mergeable | Checks if the PR mergeable_state attribute is clean, indicating that there are no conflicts, the PR is approve, and all status checks have passed. When specified, the `terraform_github_token` secret is also required. | `boolean` | `false` | no | `Apply` |
| clean_files | Whether or not to delete the *.tf and the *.auto.tfvars files after completing the Terraform steps.  This should be set to true when using remote modules as the module sources will contain the PAT in clear text. | `boolean` | `true` | no | `Plan`, `Apply` |
| infracost_behavior | Behavior for the infracost actions.  Options are update, delete-and-new, hide-and-new, new. | `string` | `new` | no | `Plan` |
| oidc_assume_role | Role name to use with OIDC authentication from GitHub to AWS. | `string` | `''` | no | `Lint`, `Plan`, `Apply` |
| oidc_region | Name of the region to use in the STS session when authenticating to AWS with OIDC. | `string` | `''` | no | `Lint`, `Plan`, `Apply` |
| plan_file | Name of the plan file artifact to download for use with an apply. | string | - | no | `Apply` |
| runs_on_labels | List of labels to use in the runs-on attribute of the jobs for routing to a runner. | `string` | `'["self-hosted", "linux", "terraform", "aws"]'` | no | `Lint`, `Plan`, `Apply`, `Plan-Apply` |
| workflow_file_name | Filename for the workflow file that is calling this workflow. | `string` | - | yes | `Apply` |
| working_dir | Directory containing the root-level Terraform module to be initialized, linted, planned, applied. | `string` | - | yes | `Lint`, `Plan`, `Apply`, `Plan-Apply` |
| child_terraform_dir | Directory containing root Terraform modules that are referenced by modules in the working_dir input. This should be used when a repo has it's own terraform `main.tf` in addition to the files in `/env/` | `string` | - | no | `Lint`, `Plan`, `Apply` |
| set_head_ref | Whether to checkout the head branch associated to the PR that triggered the workflow.  Used to better support running workflows based on comments. | `boolean` | `false` | no | `Plan`, `Apply` |

### Secrets
| Name | Description | Type | Required | Jobs |
|------|-------------|------|---------|------|
| github_token_value | Value of a Personal Access Token with org-wide repository read access.  Used to init Terraform modules with remote, private sources. | `string` | no | `Lint`, `Plan`, `Apply` |
| infracost_api_key | Secret containing an [Infracost API key](https://www.infracost.io/docs/#2-get-api-key). | `string` | no | `Plan` |
| terraform_github_token | GitHub token used with the Terraform GitHub provider to manage GitHub repositories and other organization settings.  If used along with `check_mergeable` the user associated to this token must have merge permissions to the PR's target branch. | `string` | no | `Plan`, `Apply` |
| cloudflare_api_token | Value of a Cloudflare API Token used for running terraform against Cloudflare resources. | `string` | no | `Plan`, `Apply` | 

### Example Usage - Lint (Remote Module)
```yml
jobs:
  call_terraform_lint_env:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/terraform-lint.yml@v0.7.0
    with:
      working_dir: './env/staging'
      init: true
      runs_on_labels: '["self-hosted", "linux", "terraform", "aws", "dev"]'
    secrets:
      github_token_repo_read: ${{ secrets.TERRAFORM_GITHUB_TOKEN }} # TERRAFORM_GITHUB_TOKEN needs to be configured as a repository secret in the root-module's repository settings
```

### Example Usage - Plan (Local Module)
```yml
jobs:
  call_terraform_plan_workflow:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/terraform-plan.yml@v0.7.0
    with:
      working_dir: './env/staging'
      runs_on_labels: '["self-hosted", "linux", "terraform", "aws", "dev"]'
    if: github.event_name == 'pull_request'
```

### Example Usage - Plan (Using `child_terraform_dir`)
```yml
jobs:
  call_terraform_plan_workflow:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/terraform-plan.yml@v0.7.0
    with:
      working_dir: './terraform/env/staging'
      child_terraform_dir: './terraform'
      runs_on_labels: '["self-hosted", "linux", "terraform", "aws", "dev"]'
    if: github.event_name == 'pull_request'
```

### Example Usage - Apply (Local Module)
```yml
jobs:
  call_terraform_apply_workflow:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/terraform-apply.yml@v0.7.0
    with:
      working_dir: './env/staging'
      runs_on_labels: '["self-hosted", "linux", "terraform", "aws", "dev"]'
      workflow_file_name: staging.yml
    secrets:
      REPO_ACCESS_TOKEN: ${{ secrets.REPO_ACCESS_TOKEN }}
    if: github.event_name == 'push'
```

### Example Usage - Apply on Comment
```yml
jobs:
  call_terraform_apply_workflow:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/terraform-apply.yml@v0.7.0
    with:
      working_dir: './env/production'
      runs_on_labels: '["ubuntu-latest"]' #'["self-hosted", "linux", "terraform", "aws", "dev"]'
      workflow_file_name: production.yml
      oidc_assume_role: 'arn:aws:iam::312498070417:role/github_oidc_access'
      oidc_region: 'us-east-1'
      check_mergeable: true
    secrets:
      github_token_repo_read: ${{ secrets.TERRAFORM_GITHUB_TOKEN }}
      terraform_github_token: ${{ secrets.TERRAFORM_GITHUB_TOKEN }} # This must have permissions to merge the repo in order for the mergeable_state attribute to be returned correctly.
    if: contains(github.event.comment.html_url, '/pull/') && contains(github.event.comment.body, '/terraform apply production')
```

## Packer
Workflows for validating and building AMIs with Packer.

*Requires a runner with Docker installed and network access to SSH (or RDP/WinRM for Windows) to the temporary instance.*

### Jobs
**Packer Lint** - Runs the `packer validate` command to verify the template syntax.
**Packer Build** - Builds the specified target templates.

### Inputs
| Name | Description | Type | Default | Required | Jobs |
|------|-------------|------|---------|----------|------|
| check_mergeable | Checks if the PR mergeable_state attribute is clean, indicating that there are no conflicts, the PR is approve, and all status checks have passed. When specified, the `packer_github_token` secret is also required. | `boolean` | `false` | no | `Build` |
| extra_arguments | Extra arguments (such as var-file) to pass to the Packer command. | `string` | `''` | no | `Build` |
| get_pr_data | Whether or not to use the GitHub API to gather information about the PR associated to the event that triggered the workflow. | `boolean` | `true` | no | `Build` |
| oidc_assume_role | Role name to use with OIDC authentication from GitHub to AWS. | `string` | `''` | no | `Lint`, `Build` |
| oidc_region | Name of the region to use in the STS session when authenticating to AWS with OIDC. | `string` | `''` | no | `Lint`, `Build` |
| packer_version | Version of Packer to install. | `string` | `latest` | no | `Lint`, `Build` |
| runs_on_labels | List of labels to use in the runs-on attribute of the jobs for routing to a runner. | `string` | `'["self-hosted", "linux", "terraform", "aws"]'` | no | `Lint`, `Build` |
| target_template | Template file to build. | `string` | `'.'` | no | `Build` |
| working_directory | Directory containing the root-level Terraform module to be initialized, linted, planned, applied. | `string` | - | yes | `Lint`, `Build` |

### Secrets
| Name | Description | Type | Required | Jobs |
|------|-------------|------|---------|------|
| packer_github_token | GitHub token used when `check_mergeable` is true to query the API for mergeability status. The user that owns this token must have merge permissions on the repo. | `string` | no | `Lint`, `Build` |

### Example Usage - Lint
```yml
jobs:
 packer_validate:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/packer-lint.yml@v0.7.0
    with:
      working_dir: './packer/aws/amazon-eks-node'
      runs_on_labels: '["ubuntu-latest"]'
      oidc_assume_role: 'arn:aws:iam::312498070417:role/github_oidc_access'
      oidc_region: 'us-east-1'
    if: github.event_name == 'pull_request'
```

### Example Usage - Build on Comment
```yml
packer_build_dev:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/packer-build.yml@v0.7.0
    with:
      working_directory: './packer/aws/amazon-eks-node'
      runs_on_labels: '["ubuntu-latest"]'
      extra_arguments: '-var-file=dev.pkrvars.hcl'
      oidc_assume_role: 'arn:aws:iam::312498070417:role/github_oidc_access'
      oidc_region: 'us-east-1'
      check_mergeable: true
    secrets:
      packer_github_token: ${{ secrets.TERRAFORM_GITHUB_TOKEN }}
    if: contains(github.event.comment.html_url, '/pull/') && github.event.comment.body == '/packer build dev'
```


## Kubernetes
Workflow for checking deprecated kubernetes API Version in manifest files.



### Jobs
**kuberntes-api-version-check** - Runs the `pluto detect-files` command against a provided folder to check for deprecated api version in all manifest files present.

### Inputs
| Name | Description | Type | Default | Required | Jobs |
|------|-------------|------|---------|----------|------|
| target_version | Target version of kubernetes to check for presence of deprecations | `string` | `'1.22'` | no | `kuberntes-api-version-check` |
| runs_on_labels | List of labels to use in the runs-on attribute of the jobs for routing to a runner. | `string` | `'["self-hosted", "linux", "terraform", "aws"]'` | no | `kuberntes-api-version-check` |
| working_directory | Directory containing the manifest files to check for deprecations. | `string` | - | yes | `kuberntes-api-version-check` |

### Example Usage - kuberntes-api-version-check
```yml
jobs:
 kubernetes_api_version_checks:
    uses: sportngin/se-actions-workflow-templates/.github/workflows/kubernetes-api-version-check.yml@v0.7.0
    with:
      working_dir: './kubernetes'
      runs_on_labels: '["ubuntu-latest"]'
      target_version: '1.23'
    if: github.event_name == 'pull_request'
```