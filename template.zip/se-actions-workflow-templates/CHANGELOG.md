# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v1.5.1] - 2023-01-31
### Added
- Added the github actions `join()` operator so `stderr` to `stdout` are combined to post successful and unsuccessful `terraform plan`/`terraform apply` to PR.
- Removed trivial steps in `terraform-plan.yml` and `terraform-apply.yml`.

## [v1.5.0] - 2023-01-27
### Changed
- Updated the packer lint and build workflows to use the new `setup-packer` Action.  This changed the `target_templates` input to `target_template` and added the `packer_version` input.
- Corrected the formatting in the `CHANGELOG.md` file for the previous two releases.

## [v1.4.0] - 2023-01-24
### Changed
- Added `stderr` capturing to post errors from `terraform apply` to the corresponding PR.

## [v1.3.0] - 2023-01-19
### Changed
- Added `fail_output` step to post `terraform plan` errors to the corresponding PR.

## [v1.2.0] - 2023-01-05
### Added
- Added a new github action template to check for deprecated kubernetes api versions in manifest files.

## [v1.1.2] - 2022-09-28
### Changed
- Update the logic used in the checkout steps so that the head branch step is not run on pull requests, and the default checkout is run for pull requests or comments that don't have the set_head_ref input set to true.

## [v1.1.1] - 2022-09-20
### Changed
- Added the child_terraform_dir input and step to the terraform-apply workflow.
- Updated the `Checkout Main Branch` conditional to use `true` instead of `'true'`.
- Added `github.event_name == 'issue_comment'` to the step that gets the PR data from the API.
- Updated the step to upload the plan artifact to perform this action on issue_comments as well.

## [v1.1.0] - 2022-09-14
### Added
- `set_head_ref` input and associated steps to provide the option of checking out the branch associated to the PR instead of main, resolving issues with the PR comment-based workflows.

## [v1.0.1] - 2022-09-07
### Added
- `child_terraform_dir` input and associated step to the Lint workflow.

## [v1.0.0] - 2022-09-06
### Added
- `cloudflare_api_token` secret in both `terraform-plan.yml` and `terraform-apply.yml`, along with associated steps to add it to a .auto.tfvars file for use in workflows that run Terraform containing Cloudflare resources.
- `child_terraform_dir` input and associated steps to tokenize remote modules in a directory other than the root-level module.  Used when the root-level module calls local modules that then reference Git sourced modules in the sportngin organization.

## [v0.7.0] - 2022-06-16
### Added
- Workflows to lint and build Packer templates.

## [v0.6.1] - 2022-06-13
### Changed
- Commented out the `Show results` step in the `terraform_apply.yaml` workflow.

## [v0.6.0] - 2022-06-10
### Added
- Adds support to authenticate with [OIDC](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services).
- Adds steps to the `terraform-apply.yml` workflow to enable applying plans based on PR comments rather than just pushes to certain branches, based on the `check_mergeable` input.
- Added a step to the `terraform-apply.yml` workflow to post the results of the `terraform apply` command to the PR comments.

### Changed
- Updated the script in the post_plan_to_pr to include the directory that the plan was created in.

## [v0.5.0] - 2022-03-22

### Added
- Gordon Deployment reusable workflow.
- Kustomize package reusable workflow.

## [v0.4.1] - 2022-01-04
### Changed
- Allow the `post_plan_to_pr` step to continue on error, to resolve issues with plans that are too long for comments.

## [v0.4.0] - 2021-12-28
### Added
- Infracost steps to the `terraform-plan.yml` workflow.

## [v0.3.0] - 2021-12-21
### Added
- `github_token_repo_read` secret in the `terraform-*` workflows to add support for remote, private modules.
- Step to add tokenized Git URL in module source and `clean_files` input in the `terraform-plan.yml` and `terraform-apply.yml` workflows to add remove `.tf` and `.auto.tfvars` files which may contain sensitive information.
- `terraform_github_token` secret to be used with the GitHub Terraform provider.

## [v0.2.0] - 2021-12-08
### Added
- `runs_on_labels` input in the `terraform-*` workflows to enable the calling workflow to handle runner routing.

### Changed
- Uncommented the artifact upload job so that the generated plan.tfplan file is stored as an artifact in the repo.
- Fixed the `terraform-apply.yml` job so that it is able to download the plan file from the `terraform-plan.yml` workflow by using the `dawidd6/action-download-artifact@v2` action.

## [v0.1.0] - 2021-11-18
Initial release with reusable Terraform workflows.
